CREATE DATABASE IF NOT EXISTS sqlgrey CHARACTER SET latin1;

GRANT ALL on sqlgrey.* to 'sqlgrey'@'localhost';

flush privileges;
